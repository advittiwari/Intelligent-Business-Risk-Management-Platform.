# Intelligent Business Risk Management Platform

A Java-based educational prototype demonstrating how Data Structures and Algorithms-II concepts can help organize risk records, analyse dependencies, prioritize mitigation tasks, and plan activities under budget and scheduling constraints.

> **Important:** The Java source in this repository is a demonstration implementation created from the project description in the accompanying report. Review it and align it with the implementation you actually present in your viva. It uses illustrative sample data, not live business data.

## Problem Statement

Manual risk management can make it difficult to identify critical risks, understand dependencies, allocate limited mitigation budgets, and schedule mitigation activities. This prototype demonstrates explainable DSA techniques for these tasks using simulated data.

## Objectives

- Store and retrieve business risk records.
- Represent dependencies between risks using a graph.
- Explore connected risks with BFS and DFS.
- Calculate shortest dependency paths with Dijkstra's algorithm.
- Select mitigation tasks under a budget using 0/1 Knapsack.
- Demonstrate conflict-free scheduling with backtracking and graph colouring.
- Find budget-matching subsets and use a simple Branch and Bound search.
- Demonstrate balanced indexing with a Red-Black Tree.

## Repository Structure

```text
Intelligent-Business-Risk-Management-Platform/
├── Documentation/
│   └── PBL_Final_Report_Month3.docx
├── PPTs/
│   └── README.md
├── Research paper/
│   └── README.md
├── Source-Code/
│   ├── Main.java
│   ├── Risk.java
│   ├── RiskGraph.java
│   ├── DynamicProgramming.java
│   ├── SchedulingAlgorithms.java
│   ├── BranchAndBound.java
│   └── RedBlackTree.java
├── .gitignore
└── README.md
```

## DSA Concepts Demonstrated

| Concept | Demonstration |
|---|---|
| HashMap | Direct lookup of a risk by ID |
| Graph / adjacency list | Dependencies between risks |
| BFS / DFS | Explore connected risks |
| Dijkstra + min-heap priority queue | Shortest weighted dependency path |
| 0/1 Knapsack | Select mitigation tasks within a budget |
| Backtracking | Assign requests to capacity-limited time slots |
| Graph colouring | Assign different time slots to conflicting activities |
| Sum of Subsets | Find cost combinations matching a target |
| Branch and Bound | Search for a high-value mitigation selection |
| Red-Black Tree | Balanced index of risk records |

## Requirements

- Java Development Kit (JDK) 17 or newer recommended.
- No third-party libraries required.

## Run the Demo

Open a terminal in the `Source-Code` directory and run:

```bash
javac *.java
java Main
```

The program prints illustrative results for the sample risks and algorithm demonstrations.

## Testing Notes

The program includes sample demonstrations for risk lookup, graph traversal, shortest paths, budget selection, scheduling, subset selection, Branch and Bound, and Red-Black Tree lookup. These are educational examples and are not a substitute for testing against real business data.

## Limitations

- Uses a small, hard-coded illustrative dataset.
- Does not connect to a live database, external API, or real-time business systems.
- Risk scores and costs are examples, not professional risk assessments.
- The Branch and Bound demonstration is intended for a small task set.

## Future Improvements

- Add file/database persistence and a user interface.
- Use validated business datasets and documented risk scoring.
- Benchmark algorithms on larger datasets.
- Add user roles, audit logging, and input validation.
- Compare algorithm results against established risk-management processes.

## Documentation

See [`Documentation/PBL_Final_Report_Month3.docx`](Documentation/PBL_Final_Report_Month3.docx) for the submitted final PBL report.

## Academic Context

- Course: Data Structures & Algorithms – II (CCSE0301)
- Project title: Intelligent Business Risk Management Platform
- SDG: SDG 8 – Decent Work and Economic Growth
