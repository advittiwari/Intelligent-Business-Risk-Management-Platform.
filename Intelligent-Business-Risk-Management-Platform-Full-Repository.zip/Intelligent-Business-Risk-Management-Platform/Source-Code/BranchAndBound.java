import java.util.*;

/**
 * Small exhaustive branch-and-bound style search. It prunes a branch when
 * its current cost exceeds the budget or its optimistic remaining benefit
 * cannot beat the best solution found so far.
 */
public class BranchAndBound {
    public static List<Risk> select(List<Risk> risks, int budget) {
        if (budget < 0) throw new IllegalArgumentException("Budget cannot be negative");
        List<Risk> best = new ArrayList<>();
        int[] bestBenefit = {0};
        int[] suffixBenefit = new int[risks.size() + 1];
        for (int i = risks.size() - 1; i >= 0; i--) {
            suffixBenefit[i] = suffixBenefit[i + 1] + risks.get(i).getMitigationBenefit();
        }
        search(0, risks, budget, 0, 0, new ArrayList<>(), best, bestBenefit, suffixBenefit);
        return best;
    }

    private static void search(int i, List<Risk> risks, int budget, int cost, int benefit,
                               List<Risk> chosen, List<Risk> best, int[] bestBenefit,
                               int[] suffixBenefit) {
        if (cost > budget) return;
        if (benefit + suffixBenefit[i] <= bestBenefit[0]) return;
        if (i == risks.size()) {
            if (benefit > bestBenefit[0]) {
                bestBenefit[0] = benefit;
                best.clear();
                best.addAll(chosen);
            }
            return;
        }

        Risk r = risks.get(i);
        chosen.add(r);
        search(i + 1, risks, budget, cost + r.getMitigationCost(),
               benefit + r.getMitigationBenefit(), chosen, best, bestBenefit, suffixBenefit);
        chosen.remove(chosen.size() - 1);
        search(i + 1, risks, budget, cost, benefit, chosen, best, bestBenefit, suffixBenefit);
    }
}
