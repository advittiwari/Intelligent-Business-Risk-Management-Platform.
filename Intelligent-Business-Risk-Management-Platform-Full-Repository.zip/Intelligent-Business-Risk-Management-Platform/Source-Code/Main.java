import java.util.*;

/** Entry point for the educational project prototype. */
public class Main {
    public static void main(String[] args) {
        List<Risk> risks = Arrays.asList(
            new Risk("R1", "Supplier disruption", "Operational", 9, 7, 30),
            new Risk("R2", "Payment fraud", "Financial", 8, 5, 25),
            new Risk("R3", "Data outage", "Technology", 10, 8, 40),
            new Risk("R4", "Staff shortage", "Operational", 6, 3, 12),
            new Risk("R5", "Compliance delay", "Legal", 7, 4, 18)
        );

        System.out.println("=== Intelligent Business Risk Management Platform ===");
        System.out.println("\n1. Risk records");
        risks.forEach(System.out::println);

        Map<String, Risk> directLookup = new HashMap<>();
        for (Risk r : risks) directLookup.put(r.getId(), r);
        System.out.println("\n2. HashMap lookup R3: " + directLookup.get("R3"));

        RiskGraph graph = new RiskGraph();
        risks.forEach(graph::addRisk);
        graph.addDependency("R1", "R3", 4);
        graph.addDependency("R1", "R4", 2);
        graph.addDependency("R2", "R3", 3);
        graph.addDependency("R3", "R5", 5);
        graph.addDependency("R4", "R5", 2);

        System.out.println("\n3. BFS from R1: " + graph.bfs("R1"));
        System.out.println("4. DFS from R1: " + graph.dfs("R1"));
        System.out.println("5. Dijkstra distances from R1: " + graph.dijkstra("R1"));

        int budget = 12;
        List<Risk> dpSelection = DynamicProgramming.knapsack(risks, budget);
        System.out.println("\n6. Knapsack selection within budget " + budget + ": " + ids(dpSelection));
        System.out.println("   Total cost=" + totalCost(dpSelection) + ", benefit=" + totalBenefit(dpSelection));

        int[] seats = {30, 20, 15, 10};
        int[] capacities = {40, 35};
        int[] assigned = new int[seats.length];
        boolean feasible = SchedulingAlgorithms.assignRequests(seats, capacities.clone(), assigned);
        System.out.println("\n7. Capacity scheduling feasible: " + feasible + ", slots=" + Arrays.toString(assigned));

        boolean[][] conflicts = {
            {false, true,  true,  false},
            {true,  false, true,  true },
            {true,  true,  false, true },
            {false, true,  true,  false}
        };
        int[] colours = SchedulingAlgorithms.graphColouring(conflicts, 3);
        System.out.println("8. Graph colouring with 3 slots: " + Arrays.toString(colours));

        int[] costs = {3, 5, 7, 2, 8, 4};
        System.out.println("9. Subsets summing to 15: " + SchedulingAlgorithms.sumOfSubsets(costs, 15));

        List<Risk> bbSelection = BranchAndBound.select(risks, budget);
        System.out.println("10. Branch-and-bound selection: " + ids(bbSelection)
                + ", cost=" + totalCost(bbSelection) + ", benefit=" + totalBenefit(bbSelection));

        RedBlackTree index = new RedBlackTree();
        risks.forEach(index::put);
        System.out.println("11. Red-Black Tree lookup R4: " + index.get("R4"));
        System.out.println("12. Red-Black Tree missing lookup RX: " + index.get("RX"));
        System.out.println("\nDemo complete. All figures are illustrative.");
    }

    private static List<String> ids(List<Risk> risks) {
        List<String> ids = new ArrayList<>();
        for (Risk r : risks) ids.add(r.getId());
        return ids;
    }
    private static int totalCost(List<Risk> risks) {
        return risks.stream().mapToInt(Risk::getMitigationCost).sum();
    }
    private static int totalBenefit(List<Risk> risks) {
        return risks.stream().mapToInt(Risk::getMitigationBenefit).sum();
    }
}
