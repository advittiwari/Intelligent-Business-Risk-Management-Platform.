import java.util.*;

/** Dynamic-programming demonstrations for budget-constrained mitigation. */
public class DynamicProgramming {
    public static List<Risk> knapsack(List<Risk> risks, int budget) {
        if (budget < 0) throw new IllegalArgumentException("Budget cannot be negative");
        int n = risks.size();
        int[][] dp = new int[n + 1][budget + 1];

        for (int i = 1; i <= n; i++) {
            Risk risk = risks.get(i - 1);
            int cost = risk.getMitigationCost();
            int benefit = risk.getMitigationBenefit();
            for (int b = 0; b <= budget; b++) {
                dp[i][b] = dp[i - 1][b];
                if (cost <= b) {
                    dp[i][b] = Math.max(dp[i][b], dp[i - 1][b - cost] + benefit);
                }
            }
        }

        List<Risk> selected = new ArrayList<>();
        int b = budget;
        for (int i = n; i > 0; i--) {
            if (dp[i][b] != dp[i - 1][b]) {
                Risk risk = risks.get(i - 1);
                selected.add(risk);
                b -= risk.getMitigationCost();
            }
        }
        Collections.reverse(selected);
        return selected;
    }
}
