/**
 * Minimal Red-Black Tree index from String risk ID to Risk record.
 * Includes insertion and lookup for demonstration purposes.
 */
public class RedBlackTree {
    private static final boolean RED = true;
    private static final boolean BLACK = false;
    private Node root;

    private static class Node {
        String key;
        Risk value;
        Node left, right, parent;
        boolean colour = RED;
        Node(String key, Risk value) { this.key = key; this.value = value; }
    }

    public void put(Risk risk) {
        Node z = new Node(risk.getId(), risk);
        Node parent = null;
        Node current = root;
        while (current != null) {
            parent = current;
            int cmp = z.key.compareTo(current.key);
            if (cmp == 0) { current.value = risk; return; }
            current = cmp < 0 ? current.left : current.right;
        }
        z.parent = parent;
        if (parent == null) root = z;
        else if (z.key.compareTo(parent.key) < 0) parent.left = z;
        else parent.right = z;
        fixInsert(z);
    }

    public Risk get(String key) {
        Node current = root;
        while (current != null) {
            int cmp = key.compareTo(current.key);
            if (cmp == 0) return current.value;
            current = cmp < 0 ? current.left : current.right;
        }
        return null;
    }

    private void fixInsert(Node z) {
        while (z.parent != null && z.parent.colour == RED) {
            Node p = z.parent;
            Node g = p.parent;
            if (p == g.left) {
                Node uncle = g.right;
                if (colourOf(uncle) == RED) {
                    p.colour = BLACK;
                    uncle.colour = BLACK;
                    g.colour = RED;
                    z = g;
                } else {
                    if (z == p.right) { z = p; rotateLeft(z); p = z.parent; g = p.parent; }
                    p.colour = BLACK;
                    g.colour = RED;
                    rotateRight(g);
                }
            } else {
                Node uncle = g.left;
                if (colourOf(uncle) == RED) {
                    p.colour = BLACK;
                    uncle.colour = BLACK;
                    g.colour = RED;
                    z = g;
                } else {
                    if (z == p.left) { z = p; rotateRight(z); p = z.parent; g = p.parent; }
                    p.colour = BLACK;
                    g.colour = RED;
                    rotateLeft(g);
                }
            }
        }
        root.colour = BLACK;
    }

    private boolean colourOf(Node n) { return n == null ? BLACK : n.colour; }

    private void rotateLeft(Node x) {
        Node y = x.right;
        x.right = y.left;
        if (y.left != null) y.left.parent = x;
        y.parent = x.parent;
        if (x.parent == null) root = y;
        else if (x == x.parent.left) x.parent.left = y;
        else x.parent.right = y;
        y.left = x;
        x.parent = y;
    }

    private void rotateRight(Node x) {
        Node y = x.left;
        x.left = y.right;
        if (y.right != null) y.right.parent = x;
        y.parent = x.parent;
        if (x.parent == null) root = y;
        else if (x == x.parent.right) x.parent.right = y;
        else x.parent.left = y;
        y.right = x;
        x.parent = y;
    }
}
