import java.util.*;

/** Small backtracking and graph-colouring examples for activity scheduling. */
public class SchedulingAlgorithms {
    public static boolean assignRequests(int[] seats, int[] slotCapacities, int[] assignedSlot) {
        Arrays.fill(assignedSlot, -1);
        return assignAt(0, seats, slotCapacities, assignedSlot);
    }

    private static boolean assignAt(int index, int[] seats, int[] capacities, int[] assigned) {
        if (index == seats.length) return true;
        for (int slot = 0; slot < capacities.length; slot++) {
            if (capacities[slot] >= seats[index]) {
                capacities[slot] -= seats[index];
                assigned[index] = slot;
                if (assignAt(index + 1, seats, capacities, assigned)) return true;
                capacities[slot] += seats[index];
                assigned[index] = -1;
            }
        }
        return false;
    }

    /** Returns a colour/slot per vertex, or null if no colouring is found. */
    public static int[] graphColouring(boolean[][] conflict, int colourCount) {
        int n = conflict.length;
        int[] colours = new int[n];
        Arrays.fill(colours, -1);
        if (colour(0, conflict, colours, colourCount)) return colours;
        return null;
    }

    private static boolean colour(int vertex, boolean[][] graph, int[] colours, int count) {
        if (vertex == graph.length) return true;
        for (int c = 0; c < count; c++) {
            if (safeColour(vertex, c, graph, colours)) {
                colours[vertex] = c;
                if (colour(vertex + 1, graph, colours, count)) return true;
                colours[vertex] = -1;
            }
        }
        return false;
    }

    private static boolean safeColour(int vertex, int colour, boolean[][] graph, int[] colours) {
        for (int other = 0; other < graph.length; other++) {
            if (graph[vertex][other] && colours[other] == colour) return false;
        }
        return true;
    }

    public static List<List<Integer>> sumOfSubsets(int[] values, int target) {
        List<List<Integer>> answers = new ArrayList<>();
        findSubsets(0, values, target, new ArrayList<>(), answers);
        return answers;
    }

    private static void findSubsets(int index, int[] values, int remaining,
                                    List<Integer> chosen, List<List<Integer>> answers) {
        if (remaining == 0) {
            answers.add(new ArrayList<>(chosen));
            return;
        }
        if (index == values.length || remaining < 0) return;
        chosen.add(values[index]);
        findSubsets(index + 1, values, remaining - values[index], chosen, answers);
        chosen.remove(chosen.size() - 1);
        findSubsets(index + 1, values, remaining, chosen, answers);
    }
}
