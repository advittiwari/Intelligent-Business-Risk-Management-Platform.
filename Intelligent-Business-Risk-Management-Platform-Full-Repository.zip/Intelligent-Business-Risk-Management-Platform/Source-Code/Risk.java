import java.util.Objects;

/** A simple illustrative business risk record. */
public class Risk {
    private final String id;
    private final String name;
    private final String category;
    private final int severity;
    private final int mitigationCost;
    private final int mitigationBenefit;

    public Risk(String id, String name, String category, int severity,
                int mitigationCost, int mitigationBenefit) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("Risk ID is required");
        if (severity < 1 || severity > 10) throw new IllegalArgumentException("Severity must be 1-10");
        if (mitigationCost < 0 || mitigationBenefit < 0) throw new IllegalArgumentException("Cost/benefit cannot be negative");
        this.id = id;
        this.name = Objects.requireNonNull(name);
        this.category = Objects.requireNonNull(category);
        this.severity = severity;
        this.mitigationCost = mitigationCost;
        this.mitigationBenefit = mitigationBenefit;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public int getSeverity() { return severity; }
    public int getMitigationCost() { return mitigationCost; }
    public int getMitigationBenefit() { return mitigationBenefit; }

    @Override
    public String toString() {
        return id + " - " + name + " [" + category + ", severity=" + severity
                + ", cost=" + mitigationCost + ", benefit=" + mitigationBenefit + "]";
    }
}
