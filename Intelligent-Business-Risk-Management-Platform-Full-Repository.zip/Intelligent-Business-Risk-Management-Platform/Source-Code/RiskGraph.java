import java.util.*;

/** Weighted, directed dependency graph for illustrative risk records. */
public class RiskGraph {
    private final Map<String, Risk> risks = new LinkedHashMap<>();
    private final Map<String, List<Edge>> adjacency = new LinkedHashMap<>();

    public void addRisk(Risk risk) {
        risks.put(risk.getId(), risk);
        adjacency.computeIfAbsent(risk.getId(), ignored -> new ArrayList<>());
    }

    public void addDependency(String fromId, String toId, int weight) {
        if (!risks.containsKey(fromId) || !risks.containsKey(toId)) {
            throw new IllegalArgumentException("Both risk IDs must exist before adding a dependency");
        }
        if (weight < 0) throw new IllegalArgumentException("Dijkstra requires non-negative weights");
        adjacency.get(fromId).add(new Edge(toId, weight));
    }

    public Risk getRisk(String id) { return risks.get(id); }
    public Collection<Risk> getRisks() { return Collections.unmodifiableCollection(risks.values()); }

    public List<String> bfs(String startId) {
        requireRisk(startId);
        List<String> order = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        Queue<String> queue = new ArrayDeque<>();
        visited.add(startId);
        queue.add(startId);
        while (!queue.isEmpty()) {
            String current = queue.remove();
            order.add(current);
            for (Edge edge : adjacency.get(current)) {
                if (visited.add(edge.to)) queue.add(edge.to);
            }
        }
        return order;
    }

    public List<String> dfs(String startId) {
        requireRisk(startId);
        List<String> order = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        dfsVisit(startId, visited, order);
        return order;
    }

    private void dfsVisit(String id, Set<String> visited, List<String> order) {
        if (!visited.add(id)) return;
        order.add(id);
        for (Edge edge : adjacency.get(id)) dfsVisit(edge.to, visited, order);
    }

    public Map<String, Integer> dijkstra(String startId) {
        requireRisk(startId);
        Map<String, Integer> distance = new LinkedHashMap<>();
        for (String id : risks.keySet()) distance.put(id, Integer.MAX_VALUE);
        distance.put(startId, 0);

        PriorityQueue<NodeDistance> queue = new PriorityQueue<>(Comparator.comparingInt(n -> n.distance));
        queue.add(new NodeDistance(startId, 0));

        while (!queue.isEmpty()) {
            NodeDistance current = queue.poll();
            if (current.distance != distance.get(current.id)) continue;
            for (Edge edge : adjacency.get(current.id)) {
                long candidateLong = (long) current.distance + edge.weight;
                if (candidateLong < distance.get(edge.to)) {
                    int candidate = (int) candidateLong;
                    distance.put(edge.to, candidate);
                    queue.add(new NodeDistance(edge.to, candidate));
                }
            }
        }
        return distance;
    }

    private void requireRisk(String id) {
        if (!risks.containsKey(id)) throw new IllegalArgumentException("Unknown risk ID: " + id);
    }

    private static class Edge {
        final String to;
        final int weight;
        Edge(String to, int weight) { this.to = to; this.weight = weight; }
    }
    private static class NodeDistance {
        final String id;
        final int distance;
        NodeDistance(String id, int distance) { this.id = id; this.distance = distance; }
    }
}
