# Project Presentation

Upload the actual project presentation (`.pptx`) here if you have one. A presentation file was not included in the materials available for this task, so no existing presentation has been copied into this folder.
