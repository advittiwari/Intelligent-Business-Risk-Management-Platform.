# Research Paper References

Add the actual research-paper PDFs used in your project here, provided you have permission to redistribute them.

The final report lists references, but the source paper PDFs were not supplied with the report. This folder intentionally does not contain invented or copied research papers.
